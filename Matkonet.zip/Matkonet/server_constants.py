import socket

# Saving the constant variables in a dedicated file
HOST = socket.gethostname()
PORT = 5000
